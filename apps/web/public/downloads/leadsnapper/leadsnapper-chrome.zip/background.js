// src/types/scan.ts
function scoreScanLead(lead) {
  let score = 0;
  if (lead.phone || lead.enriched?.primaryPhone) score += 10;
  if (lead.websiteUrl) score += 10;
  if (lead.enriched?.primaryEmail) score += 10;
  if (lead.enriched?.social?.linkedinCompany) score += 10;
  if (lead.enriched?.social?.facebook || lead.enriched?.social?.instagram) score += 5;
  if (lead.enriched?.hasWhatsApp) score += 5;
  if (lead.enriched?.hasChatWidget === false) score += 10;
  if (lead.enriched?.hasOnlineOrdering === false && isRestaurant(lead)) score += 15;
  if (lead.enriched?.hasBookingSystem === false) score += 10;
  if ((lead.googleReviews ?? 0) > 50) score += 5;
  if ((lead.googleReviews ?? 0) > 100) score += 5;
  if (typeof lead.googleRating === "number" && lead.googleRating >= 4) score += 5;
  if (typeof lead.googleRating === "number" && lead.googleRating < 4) score += 5;
  if ((lead.enriched?.businessListings?.length ?? 0) > 0) score += 5;
  if (lead.enriched?.mentionsCompanyReg) score += 5;
  if (isRestaurant(lead)) score += 20;
  if (isEcommerce(lead)) score += 20;
  if (isConstruction(lead)) score += 25;
  if (isCyber(lead)) score += 20;
  if (isOracle(lead)) score += 40;
  if (lead.ownerName || lead.directorName) score += 10;
  if (lead.city) score += 5;
  const capped = Math.min(score, 100);
  const priority = capped >= 70 ? "Hot" : capped >= 40 ? "Warm" : "Cold";
  return { score: capped, priority };
}
function hay(lead) {
  return [
    lead.businessName,
    lead.category,
    lead.snippet,
    lead.enriched?.metaDescription,
    lead.enriched?.metaTitle
  ].join(" ").toLowerCase();
}
function isRestaurant(l) {
  return /restaurant|takeaway|cafe|café|bistro|diner|pizza|curry|kebab|sushi|food/.test(hay(l));
}
function isEcommerce(l) {
  return /shopify|woocommerce|ecommerce|e-commerce|online store|magento/.test(hay(l) + (l.enriched?.techStack ?? []).join(" ").toLowerCase());
}
function isConstruction(l) {
  return /construction|infrastructure|civil engineer|project controls|contractor|builder/.test(hay(l));
}
function isCyber(l) {
  return /saas|fintech|healthtech|healthcare|finance|nhs|insur/.test(hay(l));
}
function isOracle(l) {
  return /oracle|unifier|primavera|p6/.test(hay(l));
}

// src/background/enricher.ts
function extractWebsiteDataFn() {
  const body = document.body?.innerText ?? "";
  const html = document.documentElement?.innerHTML ?? "";
  const hrefs = [...document.querySelectorAll("a[href]")].map((a) => a.href);
  const emailRe = /\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b/g;
  const blocked = ["example.com", "test.com", "domain.com", "yourdomain", "yoursite", "sentry", "wixpress", "cloudflare", "w3.org", "schema.org"];
  const emails = [...new Set((body.match(emailRe) ?? []).filter((e) => !blocked.some((b) => e.includes(b))))];
  const phoneRe = /(\+44[\s\d\-()\+]{8,14}|0[12378]\d[\s\d\-()\+]{7,11}|\+1[\s\d\-()\+]{9,13}|\(\d{3}\)[\s\-]\d{3}\-\d{4})/g;
  const rawPhones = body.match(phoneRe) ?? [];
  const phones = [...new Set(rawPhones.map((p) => p.trim()))];
  let schemaPhone = "", schemaEmail = "", schemaAddress = "", schemaCity = "";
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    try {
      const d = JSON.parse(s.textContent ?? "");
      const items = Array.isArray(d) ? d : [d];
      for (const item of items) {
        if (/LocalBusiness|Restaurant|Organization|Store|FoodEstablishment/.test(String(item["@type"] ?? ""))) {
          schemaPhone = item.telephone ? String(item.telephone) : "";
          schemaEmail = item.email ? String(item.email) : "";
          const addr = item.address;
          schemaAddress = addr?.streetAddress ?? "";
          schemaCity = addr?.addressLocality ?? "";
          break;
        }
      }
    } catch {
    }
  }
  const social = {
    linkedinCompany: hrefs.find((h) => /linkedin\.com\/company\//i.test(h)),
    linkedinPerson: hrefs.find((h) => /linkedin\.com\/in\//i.test(h)),
    facebook: hrefs.find((h) => /facebook\.com\/(?!sharer|share|l\.php)/i.test(h)),
    instagram: hrefs.find((h) => /instagram\.com\/[a-zA-Z0-9]/i.test(h)),
    tiktok: hrefs.find((h) => /tiktok\.com\/@/i.test(h)),
    youtube: hrefs.find((h) => /youtube\.com\/(channel|c|@|user)/i.test(h)),
    xTwitter: hrefs.find((h) => /(twitter|x)\.com\/[a-zA-Z0-9_]/i.test(h)),
    whatsapp: hrefs.find((h) => /wa\.me\/|whatsapp\.com\/send|whatsapp:\/\//i.test(h))
  };
  const socialCount = Object.values(social).filter(Boolean).length;
  const socialScore = Math.min(socialCount * 15, 100);
  const whatsappUrl = social.whatsapp ?? hrefs.find((h) => /whatsapp/i.test(h)) ?? html.match(/https?:\/\/wa\.me\/[\d+%]+/)?.[0] ?? void 0;
  const hasWhatsApp = !!whatsappUrl || /whatsapp/i.test(html);
  const techStack = [];
  if (/wp-content|wp-json|wordpress/i.test(html)) techStack.push("WordPress");
  if (/cdn\.shopify\.com|Shopify\.theme/i.test(html)) techStack.push("Shopify");
  if (/woocommerce|wc-ajax/i.test(html)) techStack.push("WooCommerce");
  if (/wix\.com|wixsite/i.test(html)) techStack.push("Wix");
  if (/webflow\.io|data-wf-site/i.test(html)) techStack.push("Webflow");
  if (/__NEXT_DATA__|_next\/static/i.test(html)) techStack.push("Next.js");
  if (/squarespace|static1\.squarespace/i.test(html)) techStack.push("Squarespace");
  if (/Mage\.Cookies|\/skin\/frontend/i.test(html)) techStack.push("Magento");
  if (/angular/i.test(html)) techStack.push("Angular");
  if (/vue\.js|vuejs|__vue__/i.test(html)) techStack.push("Vue.js");
  if (/react(?!ive)|__react/i.test(html) && !techStack.includes("Next.js") && !techStack.includes("WordPress")) techStack.push("React");
  if (/hubspot/i.test(html)) techStack.push("HubSpot");
  if (/salesforce|force\.com/i.test(html)) techStack.push("Salesforce");
  let chatWidgetProvider = "";
  if (/intercom/i.test(html)) chatWidgetProvider = "Intercom";
  else if (/tawk\.to/i.test(html)) chatWidgetProvider = "Tawk.to";
  else if (/tidio/i.test(html)) chatWidgetProvider = "Tidio";
  else if (/livechat/i.test(html)) chatWidgetProvider = "LiveChat";
  else if (/zendesk/i.test(html)) chatWidgetProvider = "Zendesk";
  else if (/drift/i.test(html)) chatWidgetProvider = "Drift";
  else if (/crisp/i.test(html)) chatWidgetProvider = "Crisp";
  else if (/freshchat|freshdesk/i.test(html)) chatWidgetProvider = "Freshdesk";
  else if (/hubspot.*chat|_hsp/i.test(html)) chatWidgetProvider = "HubSpot Chat";
  else if (/olark/i.test(html)) chatWidgetProvider = "Olark";
  else if (/smartsupp/i.test(html)) chatWidgetProvider = "Smartsupp";
  else if (/purechat/i.test(html)) chatWidgetProvider = "Pure Chat";
  else if (/chatra/i.test(html)) chatWidgetProvider = "Chatra";
  const hasChatWidget = !!chatWidgetProvider;
  const hasContactForm = !!(document.querySelector('form input[type="email"]') || document.querySelector('form input[name*="email"]') || document.querySelector('form input[name*="contact"]') || document.querySelector('form[action*="contact"]') || document.querySelector('form[id*="contact"]') || document.querySelector('form[class*="contact"]'));
  const hasOnlineOrdering = /order\s+online|add\s+to\s+cart|buy\s+now|checkout|ubereats|deliveroo|just\s+eat|doordash|order\s+now|order\s+here/i.test(html + body);
  const orderPageUrl = hrefs.find((h) => /\/order|\/checkout|\/cart|\/buy|\/purchase|\/menu\/order|\/online-order/i.test(h)) ?? void 0;
  const hasBookingSystem = /book\s+now|book\s+a\s+table|reservation|make\s+a\s+booking|calendly|booksy|opentable|fresha|treatwell|resy|openTable/i.test(html + body);
  const bookingUrl = hrefs.find((h) => /\/book|\/reservation|\/appointment|\/booking|calendly|booksy|opentable|fresha/i.test(h)) ?? void 0;
  const listingPatterns = [
    ["Yelp", /yelp\.com/i],
    ["TripAdvisor", /tripadvisor\.(com|co\.uk)/i],
    ["Trustpilot", /trustpilot\.com/i],
    ["Google Business", /business\.google\.com/i],
    ["Yell", /yell\.com/i],
    ["Checkatrade", /checkatrade\.com/i],
    ["Rated People", /ratedpeople\.com/i],
    ["Bark", /bark\.com/i],
    ["Houzz", /houzz\.(com|co\.uk)/i],
    ["Clutch", /clutch\.co/i],
    ["G2", /g2\.com\/products/i],
    ["Foursquare", /foursquare\.com/i],
    ["Thomson Local", /thomsonlocal\.com/i],
    ["FreeIndex", /freeindex\.co\.uk/i],
    ["Cylex", /cylex\.(co\.uk|com)/i]
  ];
  const businessListings = [];
  const listingUrls = {};
  for (const href of hrefs) {
    for (const [name, re] of listingPatterns) {
      if (!listingUrls[name] && re.test(href)) {
        businessListings.push(name);
        listingUrls[name] = href;
      }
    }
  }
  const mentionsCompanyReg = /company\s+(?:number|no\.?|reg\.?)|registered\s+in\s+england|companies\s+house|company\s+reg/i.test(body);
  const companyNoMatch = body.match(/company\s+(?:number|no\.?|reg\.?(?:istration)?)[:\s#]*([0-9]{6,8})/i);
  const companyNumberFound = companyNoMatch?.[1] ?? void 0;
  const mentionsTrademark = /\btrademark\b|trade\s*mark|®|™|registered\s+trade/i.test(body);
  const mentionsDuns = /\bduns\b|d-u-n-s|dun\s*&\s*bradstreet|d&b\s+number/i.test(body);
  const hasNewsletter = /subscribe|newsletter|mailing\s*list/i.test(html + body);
  const hasCareersPage = !!hrefs.find((h) => /\/careers|\/jobs|\/vacancies|\/work-with-us/i.test(h));
  const hasPrivacyPolicy = !!hrefs.find((h) => /privacy/i.test(h));
  const metaTitle = document.title?.trim() ?? "";
  const metaEl = document.querySelector('meta[name="description"]');
  const metaDescription = metaEl?.content?.trim() ?? "";
  const aboutPageUrl = hrefs.find((h) => /\/about|about-us|who-we-are/i.test(h)) ?? void 0;
  const contactPageUrl = hrefs.find((h) => /\/contact|get-in-touch/i.test(h)) ?? void 0;
  const careersPageUrl = hrefs.find((h) => /\/careers|\/jobs|\/vacancies/i.test(h)) ?? void 0;
  const allPhones = [.../* @__PURE__ */ new Set([...phones, ...schemaPhone ? [schemaPhone] : []])];
  const allEmails = [.../* @__PURE__ */ new Set([...emails, ...schemaEmail ? [schemaEmail] : []])];
  let ownerName = "";
  let ownerTitle = "";
  let ownerPhone = "";
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    try {
      const d = JSON.parse(s.textContent ?? "");
      const items = Array.isArray(d) ? d : [d];
      for (const item of items) {
        const t = String(item["@type"] ?? "");
        if (/^(Person|Employee|OrganizationRole)$/.test(t)) {
          ownerName = ownerName || String(item.name ?? item.givenName ?? "");
          ownerTitle = ownerTitle || String(item.jobTitle ?? item.roleName ?? "");
          ownerPhone = ownerPhone || String(item.telephone ?? "");
        }
      }
    } catch {
    }
  }
  if (!ownerName) {
    const kwPat = /(?:owner|founder|co-?founder|proprietor|ceo|managing director|md\b|chairman|director|principal)/i;
    const nmPat = /[A-Z][a-z]+(?:\s[A-Z][a-z]+){1,2}/;
    const lines = body.split(/\n+/).filter((l) => l.length < 300);
    for (const line of lines) {
      if (!kwPat.test(line)) continue;
      const fwd = line.match(new RegExp(`(?:${kwPat.source})[:\\s,\u2013-]+` + nmPat.source, "i"));
      const rev = line.match(new RegExp(nmPat.source + `[,\\s\u2013-]+(?:${kwPat.source})`, "i"));
      const m = fwd ?? rev;
      if (m) {
        const nameHit = m[0].match(nmPat);
        if (nameHit) {
          ownerName = nameHit[0];
          const kw = m[0].match(kwPat);
          ownerTitle = kw ? kw[0].replace(/\b\w/g, (c) => c.toUpperCase()) : "";
          break;
        }
      }
    }
  }
  const ownerLinkedinUrl = hrefs.find((h) => /linkedin\.com\/in\//.test(h)) ?? "";
  const teamMembers = [];
  const teamContainers = [...document.querySelectorAll(
    '[class*="team" i], [class*="staff" i], [class*="people" i], [id*="team" i], [id*="about" i]'
  )];
  for (const container of teamContainers.slice(0, 2)) {
    const memberEls = container.querySelectorAll('article, [class*="member" i], [class*="person" i], li');
    for (const el of Array.from(memberEls).slice(0, 6)) {
      const nameEl = el.querySelector('h3, h4, h5, [class*="name" i]');
      const name = nameEl?.innerText?.trim();
      if (!name || !/^[A-Z][a-z]+ [A-Z][a-z]+/.test(name)) continue;
      const titleEl = el.querySelector('[class*="title" i], [class*="role" i], [class*="position" i], p');
      const linkedEl = el.querySelector('a[href*="linkedin.com/in/"]');
      teamMembers.push({
        name,
        title: titleEl?.innerText?.trim() ?? void 0,
        linkedinUrl: linkedEl?.href ?? void 0
      });
      if (!ownerName && titleEl) {
        const t = titleEl.innerText?.toLowerCase() ?? "";
        if (/owner|founder|director|ceo|md\b|managing/.test(t)) {
          ownerName = name;
          ownerTitle = titleEl.innerText.trim();
          ownerLinkedinUrl || (linkedEl?.href ?? "");
        }
      }
    }
    if (teamMembers.length > 0) break;
  }
  return {
    emails: allEmails,
    phones: allPhones,
    primaryEmail: allEmails[0],
    primaryPhone: allPhones[0],
    ownerName: ownerName || void 0,
    ownerTitle: ownerTitle || void 0,
    ownerPhone: ownerPhone || void 0,
    ownerLinkedinUrl: ownerLinkedinUrl || void 0,
    teamMembers,
    hasWhatsApp,
    whatsappUrl,
    social,
    socialPresenceScore: socialScore,
    techStack,
    hasChatWidget,
    chatWidgetProvider: chatWidgetProvider || void 0,
    hasContactForm,
    hasOnlineOrdering,
    orderPageUrl,
    hasBookingSystem,
    bookingUrl,
    hasNewsletter,
    hasCareersPage,
    hasPrivacyPolicy,
    businessListings,
    listingUrls,
    mentionsCompanyReg,
    companyNumberFound,
    mentionsTrademark,
    mentionsDuns,
    securitySignal: location.protocol === "https:" ? "HTTPS" : "HTTP only",
    metaTitle,
    metaDescription,
    schemaEmail,
    schemaAddress,
    schemaCity,
    aboutPageUrl,
    contactPageUrl,
    careersPageUrl,
    enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function extractMapsPlaceFn() {
  let websiteUrl = "";
  const anchors = [...document.querySelectorAll("a[href]")];
  for (const a of anchors) {
    const label = (a.getAttribute("aria-label") ?? a.getAttribute("data-tooltip") ?? "").toLowerCase();
    const href = a.href ?? "";
    if (label.includes("website") || label.includes("web site")) {
      if (href.startsWith("http") && !href.includes("google.com")) {
        websiteUrl = href;
        break;
      }
    }
  }
  if (!websiteUrl) {
    const authEl = document.querySelector('[data-item-id*="authority"] a, a[data-item-id*="authority"]');
    if (authEl?.href && !authEl.href.includes("google.com")) websiteUrl = authEl.href;
  }
  const phoneEl = document.querySelector('[data-item-id*="phone"] .Io6YTe, [data-item-id*="phone"] span');
  const phone = phoneEl?.textContent?.trim() ?? "";
  const addrEl = document.querySelector('[data-item-id="address"] .Io6YTe, button[data-item-id="address"] .rogA2c');
  const address = addrEl?.textContent?.trim() ?? "";
  const cityMatch = address.match(/,\s*([^,\d]+?)(?:,\s*[A-Z]{1,2}\d[\dA-Z]?\s*\d[A-Z]{2}|$)/);
  const city = cityMatch?.[1]?.trim() ?? "";
  const catEl = document.querySelector('button.DkEaL, [jsaction*="category"] span, .DkEaL');
  const category = catEl?.textContent?.trim() ?? "";
  const ratingEl = document.querySelector('span.ceNzKf, div.F7nice span[aria-hidden="true"]');
  const ratingVal = parseFloat(ratingEl?.textContent?.trim() ?? "");
  const rating = isNaN(ratingVal) ? null : ratingVal;
  const reviewAttr = document.querySelector('[aria-label*="review" i], .F7nice span[aria-label]')?.getAttribute("aria-label") ?? "";
  const rvMatch = reviewAttr.match(/([\d,]+)/);
  const reviews = rvMatch ? parseInt(rvMatch[1].replace(/,/g, "")) : null;
  const hoursEl = document.querySelector('.t39EBf, .WkFjNe span, [jsaction*="openhours"] .ZDu9vd');
  const openingHours = hoursEl?.textContent?.trim() ?? "";
  const descEl = document.querySelector(".PYvSYb, .WgsUrc, .HlvSq");
  const description = descEl?.textContent?.trim() ?? "";
  return { websiteUrl, phone, address, city, category, openingHours, description, rating, reviews };
}
var MAX_CONCURRENT = 3;
var queue = [];
var running = 0;
function enqueueEnrichment(lead, onResult) {
  const hasWebsite = !!lead.websiteUrl;
  const hasMapsUrl = !!lead.googleMapsUrl;
  const hasSrcUrl = !!lead.sourceUrl?.startsWith("http");
  if (!hasWebsite && !hasMapsUrl && !hasSrcUrl) {
    onResult(lead.id, null, "No URL available");
    return;
  }
  queue.push({ lead, onResult });
  drainQueue();
}
function drainQueue() {
  while (running < MAX_CONCURRENT && queue.length > 0) {
    const job = queue.shift();
    running++;
    enrichOne(job.lead).then((data) => job.onResult(job.lead.id, data)).catch((err) => job.onResult(job.lead.id, null, String(err))).finally(() => {
      running--;
      drainQueue();
    });
  }
}
async function enrichOne(lead) {
  if (lead.sourceType === "Google Maps" && lead.googleMapsUrl) {
    return enrichMapsLead(lead);
  }
  const url = lead.websiteUrl ?? lead.sourceUrl;
  if (!url?.startsWith("http")) return null;
  return enrichWebsite(url);
}
async function enrichMapsLead(lead) {
  const gmb = await visitAndRun(lead.googleMapsUrl, extractMapsPlaceFn, 15e3);
  const gmbData = gmb ?? { websiteUrl: "", phone: "", address: "", city: "", category: "", openingHours: "", description: "", rating: null, reviews: null };
  const websiteUrl = gmbData.websiteUrl || lead.websiteUrl || "";
  const webData = websiteUrl.startsWith("http") ? await enrichWebsite(websiteUrl) : null;
  const base = webData ?? emptyEnrichedData();
  return {
    ...base,
    // Override with GMB contact if website didn't find it
    primaryPhone: base.primaryPhone || gmbData.phone || void 0,
    phones: base.phones.length ? base.phones : gmbData.phone ? [gmbData.phone] : [],
    // GMB fields
    gmbWebsiteUrl: gmbData.websiteUrl || void 0,
    gmbPhone: gmbData.phone || void 0,
    gmbAddress: gmbData.address || void 0,
    gmbCity: gmbData.city || void 0,
    gmbCategory: gmbData.category || void 0,
    gmbOpeningHours: gmbData.openingHours || void 0,
    gmbDescription: gmbData.description || void 0,
    gmbRating: gmbData.rating ?? void 0,
    gmbReviews: gmbData.reviews ?? void 0,
    enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function extractAboutPageFn() {
  const body = document.body?.innerText ?? "";
  const hrefs = [...document.querySelectorAll("a[href]")].map((a) => a.href);
  let ownerName = "", ownerTitle = "", ownerPhone = "";
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    try {
      const d = JSON.parse(s.textContent ?? "");
      const items = Array.isArray(d) ? d : [d];
      for (const item of items) {
        if (/^(Person|Employee)$/.test(String(item["@type"] ?? ""))) {
          ownerName = ownerName || String(item.name ?? "");
          ownerTitle = ownerTitle || String(item.jobTitle ?? "");
          ownerPhone = ownerPhone || String(item.telephone ?? "");
        }
      }
    } catch {
    }
  }
  if (!ownerName) {
    const kwPat = /(?:owner|founder|co-?founder|proprietor|ceo|managing director|md\b|director|chairman|principal)/i;
    const nmPat = /[A-Z][a-z]+(?:\s[A-Z][a-z]+){1,2}/;
    for (const line of body.split(/\n+/).filter((l) => l.length < 300)) {
      if (!kwPat.test(line)) continue;
      const fwd = line.match(new RegExp(`(?:${kwPat.source})[:\\s,\u2013-]+` + nmPat.source, "i"));
      const rev = line.match(new RegExp(nmPat.source + `[,\\s\u2013-]+(?:${kwPat.source})`, "i"));
      const hit = (fwd ?? rev)?.[0]?.match(nmPat);
      if (hit) {
        ownerName = hit[0];
        const kw = (fwd ?? rev)?.[0]?.match(kwPat);
        ownerTitle = kw ? kw[0].replace(/\b\w/g, (c) => c.toUpperCase()) : "";
        break;
      }
    }
  }
  const teamMembers = [];
  const containers = [...document.querySelectorAll(
    '[class*="team" i], [class*="staff" i], [class*="people" i], [class*="member" i], [id*="team" i]'
  )];
  for (const container of containers.slice(0, 3)) {
    const els = container.querySelectorAll('article, li, [class*="person" i], [class*="card" i], div');
    for (const el of Array.from(els).slice(0, 8)) {
      const nameEl = el.querySelector('h2, h3, h4, h5, [class*="name" i]');
      const name = nameEl?.innerText?.trim();
      if (!name || !/^[A-Z][a-z]+ [A-Z][a-z]+/.test(name) || name.length > 60) continue;
      const titleEl = el.querySelector('[class*="title" i], [class*="role" i], [class*="position" i], p');
      const liEl = el.querySelector('a[href*="linkedin.com/in/"]');
      teamMembers.push({ name, title: titleEl?.innerText?.trim() || void 0, linkedinUrl: liEl?.href || void 0 });
      if (!ownerName && titleEl) {
        const t = titleEl.innerText?.toLowerCase() ?? "";
        if (/owner|founder|director|ceo|md\b|managing/.test(t)) {
          ownerName = name;
          ownerTitle = titleEl.innerText.trim();
        }
      }
    }
    if (teamMembers.length >= 3) break;
  }
  const ownerLinkedinUrl = hrefs.find((h) => /linkedin\.com\/in\//.test(h)) ?? "";
  return { ownerName, ownerTitle, ownerLinkedinUrl, ownerPhone, teamMembers };
}
async function enrichWebsite(url) {
  const webData = await visitAndRun(url, extractWebsiteDataFn, 12e3);
  if (!webData) return null;
  if (!webData.ownerName && webData.aboutPageUrl) {
    const aboutData = await visitAndRun(webData.aboutPageUrl, extractAboutPageFn, 1e4);
    if (aboutData?.ownerName) {
      return {
        ...webData,
        ownerName: aboutData.ownerName || webData.ownerName,
        ownerTitle: aboutData.ownerTitle || webData.ownerTitle,
        ownerLinkedinUrl: aboutData.ownerLinkedinUrl || webData.ownerLinkedinUrl,
        ownerPhone: aboutData.ownerPhone || webData.ownerPhone,
        teamMembers: aboutData.teamMembers?.length ? aboutData.teamMembers : webData.teamMembers
      };
    }
  }
  return webData;
}
async function visitAndRun(url, fn, timeoutMs) {
  let tabId;
  try {
    const tab = await chrome.tabs.create({ url, active: false, pinned: false });
    tabId = tab.id;
    await waitForLoad(tabId, timeoutMs);
    const results = await chrome.scripting.executeScript({ target: { tabId }, func: fn });
    return results[0]?.result ?? null;
  } catch (err) {
    console.warn(`[LeadSnapper] Failed to extract from ${url}:`, err);
    return null;
  } finally {
    if (tabId !== void 0) chrome.tabs.remove(tabId).catch(() => {
    });
  }
}
function emptyEnrichedData() {
  return {
    emails: [],
    phones: [],
    hasWhatsApp: false,
    social: {},
    socialPresenceScore: 0,
    techStack: [],
    hasChatWidget: false,
    hasContactForm: false,
    hasOnlineOrdering: false,
    hasBookingSystem: false,
    hasNewsletter: false,
    hasCareersPage: false,
    hasPrivacyPolicy: false,
    businessListings: [],
    listingUrls: {},
    mentionsCompanyReg: false,
    mentionsTrademark: false,
    mentionsDuns: false,
    teamMembers: [],
    securitySignal: "",
    enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function waitForLoad(tabId, timeoutMs) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, timeoutMs);
    const listener = (id, info) => {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(resolve, 800);
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// src/types/settings.ts
var DEFAULT_SETTINGS = {
  brands: [],
  presets: [],
  keywordGroups: [],
  autoSave: false,
  searchHistory: [],
  exploriumApiKey: "",
  exploriumEnabled: false,
  pdlApiKey: "",
  pdlEnabled: false,
  openmartApiKey: "",
  openmartEnabled: false,
  lushaApiKey: "",
  lushaEnabled: false,
  cognismApiKey: "",
  cognismEnabled: false,
  companiesHouseApiKey: "",
  companiesHouseEnabled: false,
  companiesHouseOnlyTest: false,
  companiesHouseUseSearch: false,
  companiesHouseUseOfficers: false,
  companiesHouseUsePsc: false,
  companiesHouseUseRegisteredAddress: false,
  enrichmentProvider: "waterfall",
  localSmbMode: true,
  flowCrmApiUrl: "",
  flowCrmApiKey: "",
  flowCrmSyncEnabled: false
};

// src/utils/storage.ts
var STORAGE_KEY = "leadsnapper_settings";
function mergeSettings(stored) {
  return {
    ...DEFAULT_SETTINGS,
    flowCrmApiUrl: stored?.flowCrmApiUrl?.trim() || "",
    flowCrmApiKey: stored?.flowCrmApiKey?.trim() || "",
    flowCrmSyncEnabled: Boolean(stored?.flowCrmSyncEnabled),
    autoSave: Boolean(stored?.autoSave)
  };
}
async function loadSettings() {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    return mergeSettings(result[STORAGE_KEY]);
  } catch {
    return structuredClone(DEFAULT_SETTINGS);
  }
}

// src/config/builtin-keys.ts
var BUILTIN_COMPANIES_HOUSE_API_KEY = "";

// src/utils/companiesHouse.ts
var API_KEY_FIELDS = [
  "companiesHouseApiKey",
  "openmartApiKey",
  "cognismApiKey",
  "lushaApiKey",
  "exploriumApiKey",
  "pdlApiKey"
];
var CH_ENDPOINT_DEFAULTS = {
  companiesHouseUseSearch: true,
  companiesHouseUseOfficers: true,
  companiesHouseUsePsc: true,
  companiesHouseUseRegisteredAddress: true
};
function chLiveModeActive(s) {
  return s.companiesHouseOnlyTest || s.localSmbMode;
}
function chApiKey(settings) {
  return settings.companiesHouseApiKey?.trim() || BUILTIN_COMPANIES_HOUSE_API_KEY.trim() || "";
}
function applyBuiltinApiKeys(settings) {
  const builtin = BUILTIN_COMPANIES_HOUSE_API_KEY.trim();
  const stored = settings.companiesHouseApiKey?.trim() ?? "";
  const key = stored || builtin;
  if (!key) return settings;
  return {
    ...settings,
    companiesHouseApiKey: key,
    companiesHouseEnabled: settings.companiesHouseEnabled ?? true
  };
}
function resolveChSettings(s) {
  const base = applyBuiltinApiKeys(s);
  if (!chLiveModeActive(base)) return base;
  return {
    ...base,
    companiesHouseEnabled: true,
    ...CH_ENDPOINT_DEFAULTS
  };
}
function mergeEnrichSettings(stored, panel) {
  const base = resolveChSettings(applyBuiltinApiKeys(stored));
  if (!panel) return base;
  const merged = { ...base, ...panel };
  for (const field of API_KEY_FIELDS) {
    const panelVal = typeof panel[field] === "string" ? panel[field].trim() : "";
    const storedVal = typeof base[field] === "string" ? base[field].trim() : "";
    merged[field] = panelVal || storedVal;
  }
  merged.companiesHouseApiKey = chApiKey(merged);
  return resolveChSettings(merged);
}

// src/utils/openmart.ts
function parseDirectorName(name) {
  const trimmed = name.trim();
  if (!trimmed) return {};
  if (trimmed.includes(",")) {
    const [last, rest] = trimmed.split(",").map((s) => s.trim());
    const first = rest?.split(/\s+/).filter(Boolean)[0];
    return { first, last };
  }
  const parts = trimmed.split(/\s+/).filter(Boolean);
  if (parts.length === 1) return { first: parts[0] };
  return { first: parts[0], last: parts.slice(1).join(" ") };
}
function rawEmail(email) {
  if (!email) return void 0;
  if (typeof email === "string") return email || void 0;
  return email.email || void 0;
}
function pickMobile(person) {
  const phones = person.phones ?? [];
  const mobile = phones.find(
    (p) => p.line_type?.toUpperCase() === "MOBILE" || p.line_type?.toUpperCase() === "CELL" || p.line_type?.toUpperCase() === "WIRELESS"
  );
  const best = mobile ?? phones.find((p) => p.phone_number || p.phone);
  const number = best?.phone_number || best?.phone || person.decision_maker?.phone || person.owner_phone;
  if (!number) return {};
  return {
    number,
    confidence: best?.confidence_grade,
    lineType: best?.line_type
  };
}
function personName(p) {
  return [p.first_name, p.last_name].filter(Boolean).join(" ").trim();
}
function titleScore(title) {
  const t = (title ?? "").toLowerCase();
  if (/founder|co-founder|cofounder/.test(t)) return 8;
  if (/\bceo\b|chief executive/.test(t)) return 7;
  if (/owner|president|managing director/.test(t)) return 6;
  if (/cto|coo|cfo|director/.test(t)) return 4;
  return 0;
}
function pickBestPerson(people) {
  if (!people.length) return void 0;
  const ranked = [...people].sort((a, b) => {
    const aMobile = pickMobile(a).number ? 10 : 0;
    const bMobile = pickMobile(b).number ? 10 : 0;
    return bMobile + titleScore(b.title) - (aMobile + titleScore(a.title));
  });
  return ranked[0];
}
function extractOpenmartPeople(task) {
  if (!task || typeof task !== "object") return [];
  const t = task;
  const arrays = [t.data, t.result, t.output, t.people, t.contacts];
  for (const c of arrays) {
    if (Array.isArray(c) && c.length > 0) return c;
  }
  for (const key of ["data", "result", "output"]) {
    const nested = t[key];
    if (nested && typeof nested === "object" && !Array.isArray(nested)) {
      const d = nested;
      for (const inner of ["people", "results", "contacts", "data"]) {
        if (Array.isArray(d[inner]) && d[inner].length > 0) {
          return d[inner];
        }
      }
    }
  }
  return [];
}
function mapOpenmartPeople(people) {
  return people.map((p) => {
    const { number, confidence, lineType } = pickMobile(p);
    return {
      name: personName(p),
      title: p.title || void 0,
      email: rawEmail(p.email),
      mobile: number,
      linkedin: p.linkedin_url || void 0,
      phoneConfidence: confidence,
      lineType
    };
  }).filter((p) => p.name);
}
function parseOpenmartTaskResult(task) {
  const raw = extractOpenmartPeople(task);
  if (!raw.length) {
    throw new Error("Openmart: no people returned for this business");
  }
  const openmartPeople = mapOpenmartPeople(raw);
  const best = pickBestPerson(raw);
  if (!best) throw new Error("Openmart: could not parse contact records");
  const name = personName(best);
  const { number } = pickMobile(best);
  return {
    ownerName: name || void 0,
    ownerTitle: best.title || void 0,
    ownerEmail: rawEmail(best.email),
    ownerMobile: number,
    ownerLinkedin: best.linkedin_url || void 0,
    openmartPeople,
    enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}

// src/utils/leadKey.ts
function leadStableKey(lead) {
  const maps = lead.googleMapsUrl || (lead.sourceUrl?.includes("/maps/place/") ? lead.sourceUrl : "");
  if (maps) {
    try {
      const u = new URL(maps);
      const cid = u.searchParams.get("cid");
      if (cid) return `maps:cid:${cid}`;
      const q = u.searchParams.get("q");
      if (q?.includes("place_id:")) return `maps:${q}`;
      return `maps:${u.pathname.split("@")[0]}`;
    } catch {
      return `maps:${maps.split("?")[0]}`;
    }
  }
  const name = (lead.businessName ?? "").toLowerCase().trim();
  const addr = (lead.address ?? lead.city ?? "").toLowerCase().trim();
  if (name) return `biz:${name}|${addr}`;
  return lead.id ?? `unknown:${Math.random()}`;
}

// src/background/worker.ts
var openTabs = /* @__PURE__ */ new Set();
var sidepanelPort = null;
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "sidepanel") return;
  sidepanelPort = port;
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (tab?.id) openTabs.add(tab.id);
  });
  port.onDisconnect.addListener(() => {
    sidepanelPort = null;
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (tab?.id) openTabs.delete(tab.id);
    });
  });
});
chrome.action.onClicked.addListener(async (tab) => {
  const tabId = tab.id;
  if (!tabId) return;
  if (openTabs.has(tabId)) {
    try {
      await chrome.sidePanel.setOptions({ tabId, enabled: false });
      openTabs.delete(tabId);
      await chrome.sidePanel.setOptions({ tabId, enabled: true });
    } catch {
      await chrome.sidePanel.open({ tabId }).catch(() => {
      });
    }
  } else {
    await chrome.sidePanel.open({ tabId }).catch(() => {
    });
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "SCAN_PAGE") {
    scanActiveTab().then((result) => {
      const payload = result ?? { leads: [], pageType: "unknown", filteredCount: 0 };
      sidepanelPort?.postMessage({ type: "SCAN_RESULTS", payload });
      if (payload.leads.length > 0) {
        startEnrichment(payload.leads);
      }
      sendResponse({ ok: true });
    });
    return true;
  }
  if (msg.type === "EXTRACT_PAGE") {
    extractActiveTab().then((data) => {
      sidepanelPort?.postMessage({ type: "PAGE_EXTRACTED", payload: data });
      if (data) {
        chrome.storage.session.set({ pendingCapture: { data, ts: Date.now() } }).catch(() => {
        });
      }
      sendResponse({ ok: !!data, data });
    });
    return true;
  }
  if (msg.type === "ENRICH_LEAD") {
    const lead = msg.payload;
    enrichCompleted.delete(leadStableKey(lead));
    enrichInFlight.delete(leadStableKey(lead));
    enqueueEnrichment(lead, (id, data, error) => {
      if (data) {
        const updatedLead = { ...lead, enriched: data };
        const { score, priority } = scoreScanLead(updatedLead);
        sidepanelPort?.postMessage({ type: "ENRICH_RESULT", payload: { id, data, score, priority } });
      } else {
        sidepanelPort?.postMessage({ type: "ENRICH_RESULT", payload: { id, data: null, error } });
      }
    });
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === "ENRICH_SESSION_LEAD") {
    const { leadId, url } = msg.payload;
    const fakeLead = { id: leadId, websiteUrl: url, sourceUrl: url, enrichStatus: "pending" };
    enqueueEnrichment(fakeLead, (id, data, error) => {
      sidepanelPort?.postMessage({ type: "SESSION_ENRICH_RESULT", payload: { leadId: id, data, error } });
    });
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === "EXPLORIUM_ENRICH") {
    const { leadId } = msg.payload;
    sidepanelPort?.postMessage({
      type: "EXPLORIUM_RESULT",
      payload: {
        leadId,
        error: "Enrichment APIs removed. Use Scan / Capture on public pages only."
      }
    });
    sendResponse({ ok: false, error: "enrichment_disabled" });
    return false;
  }
  if (false) {
    void msg;
  }
  if (msg.type === "EXPLORIUM_ENRICH_LEGACY_DISABLED") {
    const { leadId, businessName, domain, provider, ownerLinkedinUrl, ownerName, businessPhone, address, city, country, settings: settingsFromPanel } = msg.payload;
    (async () => {
      const stored = resolveChSettings(applyBuiltinApiKeys(await loadSettings()));
      const settings = settingsFromPanel ? mergeEnrichSettings(stored, mergeSettings(settingsFromPanel)) : stored;
      const expKey = settings?.exploriumApiKey ?? "";
      const pdlKey = settings?.pdlApiKey ?? "";
      try {
        let data;
        const effectiveProvider = settings?.localSmbMode ? "waterfall" : provider;
        if (effectiveProvider === "explorium") {
          if (!settings?.exploriumEnabled) throw new Error("Explorium is disabled. Enable it in Settings \u2192 B2B Enrichment APIs.");
          if (!expKey) throw new Error("No Explorium API key. Add it in Settings \u2192 API Keys.");
          data = { ...await enrichWithExplorium(businessName, domain, expKey), source: "Explorium" };
        } else if (effectiveProvider === "pdl") {
          if (!settings?.pdlEnabled) throw new Error("People Data Labs is disabled. Enable it in Settings \u2192 B2B Enrichment APIs.");
          if (!pdlKey) throw new Error("No People Data Labs API key. Add it in Settings \u2192 API Keys.");
          data = { ...await enrichWithPDL(businessName, domain, pdlKey, ownerLinkedinUrl, ownerName), source: "People Data Labs" };
        } else if (effectiveProvider === "waterfall") {
          if (!settings) throw new Error("Settings not loaded.");
          data = await enrichWithWaterfall(businessName, domain, settings, ownerLinkedinUrl, ownerName, businessPhone, country, city, address);
        } else {
          const results = await Promise.allSettled([
            expKey ? enrichWithExplorium(businessName, domain, expKey) : Promise.reject("no key"),
            pdlKey ? enrichWithPDL(businessName, domain, pdlKey, ownerLinkedinUrl, ownerName) : Promise.reject("no key")
          ]);
          const exp = results[0].status === "fulfilled" ? results[0].value : null;
          const pdl = results[1].status === "fulfilled" ? results[1].value : null;
          if (!exp && !pdl) throw new Error("Both APIs failed or no keys configured. Check Settings \u2192 API Keys.");
          data = {
            ownerName: exp?.ownerName || pdl?.ownerName,
            ownerTitle: exp?.ownerTitle || pdl?.ownerTitle,
            ownerEmail: exp?.ownerEmail || pdl?.ownerEmail,
            ownerPersonalEmail: exp?.ownerPersonalEmail || pdl?.ownerPersonalEmail,
            ownerPhone: exp?.ownerPhone || pdl?.ownerPhone,
            ownerMobile: exp?.ownerMobile || pdl?.ownerMobile,
            ownerLinkedin: exp?.ownerLinkedin || pdl?.ownerLinkedin,
            businessId: exp?.businessId || pdl?.businessId,
            prospectId: exp?.prospectId || pdl?.prospectId,
            enrichedAt: (/* @__PURE__ */ new Date()).toISOString(),
            source: exp && pdl ? "Explorium + PDL" : exp ? "Explorium" : "People Data Labs"
          };
        }
        sidepanelPort?.postMessage({ type: "EXPLORIUM_RESULT", payload: { leadId, data } });
      } catch (err) {
        const error = err instanceof Error && err.message === "MISSING_CH_KEY" ? "MISSING_CH_KEY" : String(err);
        sidepanelPort?.postMessage({ type: "EXPLORIUM_RESULT", payload: { leadId, error } });
      }
    })();
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === "UPDATE_BADGE") {
    const count = msg.payload.count;
    chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
    chrome.action.setBadgeBackgroundColor({ color: "#1F4E79" });
    sendResponse({ ok: true });
    return true;
  }
});
var enrichCompleted = /* @__PURE__ */ new Set();
var enrichInFlight = /* @__PURE__ */ new Set();
function startEnrichment(leads) {
  const enrichable = leads.filter((l) => {
    const key = leadStableKey(l);
    if (enrichCompleted.has(key) || enrichInFlight.has(key)) return false;
    const hasTarget = !!(l.googleMapsUrl || l.websiteUrl || l.sourceUrl?.includes("/maps/place/") || l.sourceType === "Google Maps");
    return hasTarget;
  });
  for (const lead of enrichable) {
    const key = leadStableKey(lead);
    enrichInFlight.add(key);
    sidepanelPort?.postMessage({
      type: "ENRICH_STATUS",
      payload: { id: lead.id, status: "enriching" }
    });
    enqueueEnrichment(lead, (id, data, error) => {
      enrichInFlight.delete(key);
      if (data) {
        enrichCompleted.add(key);
        const updatedLead = { ...lead, enriched: data };
        const { score, priority } = scoreScanLead(updatedLead);
        sidepanelPort?.postMessage({
          type: "ENRICH_RESULT",
          payload: { id, data, score, priority, error: void 0 }
        });
      } else {
        sidepanelPort?.postMessage({
          type: "ENRICH_RESULT",
          payload: { id, data: null, error: error ?? "Failed" }
        });
      }
    });
  }
}
async function injectContentScript(tabId) {
  const mf = await (await fetch(chrome.runtime.getURL("manifest.json"))).json();
  const files = mf.content_scripts?.flatMap((cs) => cs.js ?? []) ?? [];
  if (!files.length) return;
  await chrome.scripting.executeScript({ target: { tabId }, files });
  await new Promise((r) => setTimeout(r, 600));
}
async function scanActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return { leads: [], pageType: "unknown", filteredCount: 0 };
  try {
    return await chrome.tabs.sendMessage(tab.id, { type: "SCAN_PAGE" });
  } catch {
    try {
      await injectContentScript(tab.id);
      return await chrome.tabs.sendMessage(tab.id, { type: "SCAN_PAGE" });
    } catch {
      return { leads: [], pageType: "error", filteredCount: 0 };
    }
  }
}
async function enrichWithExplorium(businessName, domain, apiKey) {
  const hdrs = { "api_key": apiKey, "Content-Type": "application/json" };
  const BASE = "https://api.explorium.ai/v1";
  const matchRes = await fetch(`${BASE}/businesses/match`, {
    method: "POST",
    headers: hdrs,
    body: JSON.stringify({ businesses_to_match: [{ name: businessName, domain }] })
  });
  if (!matchRes.ok) throw new Error(`Explorium business match: ${matchRes.status} ${matchRes.statusText}`);
  const matchJson = await matchRes.json();
  const businessId = matchJson.matched_businesses?.[0]?.business_id;
  if (!businessId) throw new Error(`Business "${businessName}" not found in Explorium (domain: ${domain})`);
  const prospRes = await fetch(`${BASE}/prospects`, {
    method: "POST",
    headers: hdrs,
    body: JSON.stringify({
      mode: "full",
      page_size: 5,
      filters: {
        business_id: { values: [businessId] },
        job_level: { values: ["owner", "founder", "cxo", "c-suite", "director", "president", "partner", "vp", "board member"] }
      }
    })
  });
  if (!prospRes.ok) throw new Error(`Explorium prospects: ${prospRes.status} ${prospRes.statusText}`);
  const prospJson = await prospRes.json();
  const prospect = prospJson.data?.[0];
  if (!prospect) throw new Error("No owner / decision-maker found for this business in Explorium");
  const prospectId = prospect.prospect_id;
  const fullName = prospect.full_name || `${prospect.first_name ?? ""} ${prospect.last_name ?? ""}`.trim();
  const title = prospect.job_title ?? prospect.job_level_main ?? "";
  const linkedin = prospect.linkedin_url_array?.[0] ?? "";
  const enrichRes = await fetch(`${BASE}/prospects/contacts_information/enrich`, {
    method: "POST",
    headers: hdrs,
    body: JSON.stringify({ prospect_id: prospectId, parameters: { contact_types: ["email", "phone"] } })
  });
  if (!enrichRes.ok) throw new Error(`Explorium contact enrich: ${enrichRes.status} ${enrichRes.statusText}`);
  const enrichJson = await enrichRes.json();
  const email = enrichJson.professions_email || enrichJson.emails?.[0]?.value || "";
  const phone = enrichJson.mobile_phone || enrichJson.phone_numbers?.[0]?.value || "";
  return {
    ownerName: fullName || void 0,
    ownerTitle: title || void 0,
    ownerEmail: email || void 0,
    ownerPhone: phone || void 0,
    ownerLinkedin: linkedin || void 0,
    businessId,
    prospectId,
    enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function enrichWithPDL(businessName, domain, apiKey, ownerLinkedinUrl, ownerName) {
  const BASE = "https://api.peopledatalabs.com/v5";
  const hdrs = { "X-Api-Key": apiKey, "Content-Type": "application/json" };
  if (ownerLinkedinUrl || ownerName) {
    const body = { titlecase: true, min_likelihood: 2 };
    if (ownerLinkedinUrl) body.profile = [ownerLinkedinUrl];
    if (ownerName) body.name = ownerName;
    if (domain) body.company = domain;
    const enrichRes = await fetch(`${BASE}/person/enrich`, {
      method: "POST",
      headers: hdrs,
      body: JSON.stringify(body)
    });
    if (enrichRes.ok) {
      const enrichJson = await enrichRes.json();
      if (enrichJson.data) {
        return parsePdlPerson(enrichJson.data);
      }
    }
  }
  const safeDomain = domain.replace(/'/g, "''");
  const safeName = businessName.replace(/'/g, "''");
  const baseWhere = `job_title_levels IN ('owner','c_suite','director','vp','partner')`;
  const companyFilter = domain ? `(job_company_website='${safeDomain}' OR job_company_name='${safeName}')` : `job_company_name='${safeName}'`;
  async function pdlSearch(sql) {
    const r = await fetch(`${BASE}/person/search`, {
      method: "POST",
      headers: hdrs,
      body: JSON.stringify({ sql, size: 5, dataset: "all", titlecase: true })
    });
    if (r.status === 404) return null;
    if (!r.ok) {
      let detail = r.statusText;
      try {
        const body = await r.json();
        detail = body?.error?.message ?? body?.message ?? detail;
      } catch {
      }
      throw new Error(`PDL person search: ${r.status} \u2014 ${detail}`);
    }
    const json = await r.json();
    return json.data?.length ? json.data : null;
  }
  let results = await pdlSearch(
    `SELECT * FROM person WHERE ${companyFilter} AND ${baseWhere} AND mobile_phone IS NOT NULL`
  );
  if (!results) {
    results = await pdlSearch(`SELECT * FROM person WHERE ${companyFilter} AND ${baseWhere}`);
  }
  if (!results) {
    results = await pdlSearch(`SELECT * FROM person WHERE job_company_name='${safeName}' AND ${baseWhere}`);
  }
  if (!results) throw new Error(`No decision-makers found for "${businessName}" in People Data Labs`);
  const best = results.find((r) => r.mobile_phone) ?? results[0];
  return parsePdlPerson(best);
}
function parsePdlPerson(p) {
  const fullName = p.full_name || `${p.first_name ?? ""} ${p.last_name ?? ""}`.trim();
  const emails = Array.isArray(p.emails) ? p.emails : [];
  const workEmail = emails.find((e) => e.type === "current_professional" || e.type === "professional")?.address;
  const personalEmail = emails.find((e) => e.type === "personal")?.address;
  const anyEmail = emails[0]?.address;
  const mobile = p.mobile_phone;
  const phones = Array.isArray(p.phone_numbers) ? p.phone_numbers : [];
  const altPhone = phones.find((ph) => ph !== mobile) ?? void 0;
  return {
    ownerName: fullName || void 0,
    ownerTitle: p.job_title || void 0,
    ownerEmail: workEmail || anyEmail || void 0,
    ownerPersonalEmail: personalEmail || void 0,
    ownerMobile: mobile || void 0,
    ownerPhone: altPhone || void 0,
    ownerLinkedin: p.linkedin_url || void 0,
    businessId: p.job_company_id || void 0,
    prospectId: p.id || void 0,
    enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function dedupePhone(phone, businessPhone) {
  if (!phone) return void 0;
  if (!businessPhone) return phone;
  const norm = (p) => p.replace(/[\s\-().+]/g, "");
  return norm(phone) === norm(businessPhone) ? void 0 : phone;
}
function detectMarket(country) {
  if (!country) return "unknown";
  const c = country.toLowerCase();
  if (c.includes("united kingdom") || c === "uk" || c.includes("england") || c.includes("scotland") || c.includes("wales")) return "UK";
  if (c.includes("united states") || c === "usa" || c === "us") return "US";
  return "unknown";
}
async function enrichCompaniesHouseOnly(businessName, _domain, settings) {
  const chSettings = resolveChSettings(settings);
  if (!chApiKey(chSettings)) {
    throw new Error("MISSING_CH_KEY");
  }
  assertCompaniesHouseConfig(chSettings);
  const ch = await lookupCompaniesHouse(businessName, chSettings);
  if (!ch?.companyNumber) {
    throw new Error(
      `No UK company on Companies House for "${businessName}". Try the exact registered Ltd name.`
    );
  }
  return mapChToExplorium(ch);
}
function waterfallSource(steps) {
  return steps.filter(Boolean).join(" \u2192 ");
}
function mergeOpenmartInto(partial, om) {
  return {
    ...partial,
    ownerName: om.ownerName || partial.ownerName,
    ownerTitle: om.ownerTitle || partial.ownerTitle,
    ownerEmail: om.ownerEmail || partial.ownerEmail,
    ownerMobile: om.ownerMobile || partial.ownerMobile,
    ownerLinkedin: om.ownerLinkedin || partial.ownerLinkedin,
    openmartPeople: om.openmartPeople,
    enrichedAt: om.enrichedAt || partial.enrichedAt
  };
}
async function enrichWithWaterfall(businessName, domain, settings, ownerLinkedinUrl, ownerName, businessPhone, country, city, address) {
  if (settings.companiesHouseOnlyTest) {
    return enrichCompaniesHouseOnly(businessName, domain, settings);
  }
  const market = detectMarket(country);
  if (market === "US") {
    return enrichUsWaterfall(businessName, domain, settings, ownerName, businessPhone, city, address, country);
  }
  return enrichUkWaterfall(businessName, domain, settings, ownerName, businessPhone, city, address, country);
}
async function enrichUkWaterfall(businessName, domain, settings, ownerName, businessPhone, city, address, country) {
  let partial = {};
  const steps = [];
  const stepErrors = [];
  if (settings.localSmbMode && chLiveModeActive(settings)) {
    const chSettings = resolveChSettings(settings);
    if (!chApiKey(chSettings)) {
      stepErrors.push("Companies House: API key missing \u2014 add in Settings");
    } else {
      try {
        const ch = await lookupCompaniesHouse(businessName, chSettings);
        if (ch?.companyNumber) {
          partial = { ...mapChToExplorium(ch) };
          steps.push("Companies House");
        } else {
          stepErrors.push(`Companies House: no UK company match for "${businessName}"`);
        }
      } catch (err) {
        stepErrors.push(`Companies House: ${String(err)}`);
      }
    }
  }
  const chCompany = partial.companiesHouseCompanyName || businessName;
  const chAddress = partial.companiesHouseRegisteredAddress || address;
  const directorRaw = partial.companiesHouseDirectorName || partial.ownerName;
  const { first: dirFirst, last: dirLast } = parseDirectorName(directorRaw ?? "");
  if (settings.openmartApiKey && settings.openmartEnabled) {
    try {
      const om = await enrichWithOpenmart(businessName, domain, settings.openmartApiKey, {
        city,
        address: chAddress,
        country: country || "GB",
        companyName: chCompany,
        ownerFirstName: dirFirst,
        ownerLastName: dirLast
      });
      partial = mergeOpenmartInto(partial, om);
      steps.push("Openmart");
      const mobile = dedupePhone(om.ownerMobile, businessPhone);
      if (mobile) {
        return {
          ...partial,
          ownerMobile: mobile,
          ownerPhone: void 0,
          mobileSource: "Openmart",
          source: waterfallSource(steps),
          enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
      }
    } catch (err) {
      stepErrors.push(`Openmart: ${String(err)}`);
    }
  }
  const ukName = partial.ownerName ?? ownerName ?? directorRaw;
  const hasMobile = !!dedupePhone(partial.ownerMobile, businessPhone);
  if (!hasMobile && ukName && settings.cognismApiKey && settings.cognismEnabled) {
    const { first, last } = parseDirectorName(ukName);
    const firstName = first || ukName.split(/\s+/)[0] || "";
    const lastName = last || ukName.split(/\s+/).slice(1).join(" ");
    try {
      const r = await enrichWithCognism(firstName, lastName, chCompany, domain, settings.cognismApiKey);
      const mobile = dedupePhone(r.ownerMobile, businessPhone);
      if (mobile) {
        steps.push("Cognism");
        return {
          ...partial,
          ...r,
          ownerName: ukName,
          ownerMobile: mobile,
          mobileSource: "Cognism",
          source: waterfallSource(steps),
          enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
      }
      if (r.ownerEmail) partial = { ...partial, ownerEmail: r.ownerEmail };
    } catch (err) {
      stepErrors.push(`Cognism: ${String(err)}`);
    }
  } else if (!hasMobile && ukName && settings.cognismEnabled && !settings.cognismApiKey) {
    stepErrors.push("Cognism: API key missing");
  }
  return finishWaterfall(partial, steps, stepErrors, businessName, settings, "UK");
}
async function enrichUsWaterfall(businessName, domain, settings, ownerName, businessPhone, city, address, country) {
  let partial = {};
  const steps = [];
  const stepErrors = [];
  if (settings.openmartApiKey && settings.openmartEnabled) {
    try {
      const om = await enrichWithOpenmart(businessName, domain, settings.openmartApiKey, {
        city,
        address,
        country: country || "US"
      });
      partial = mergeOpenmartInto(partial, om);
      steps.push("Openmart");
      const mobile = dedupePhone(om.ownerMobile, businessPhone);
      if (om.ownerName && mobile) {
        return {
          ...partial,
          ownerMobile: mobile,
          ownerPhone: void 0,
          mobileSource: "Openmart",
          source: waterfallSource(steps),
          enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
      }
    } catch (err) {
      stepErrors.push(`Openmart: ${String(err)}`);
    }
  }
  const usName = partial.ownerName ?? ownerName;
  const hasMobile = !!dedupePhone(partial.ownerMobile, businessPhone);
  if (!hasMobile && settings.lushaApiKey && settings.lushaEnabled) {
    const { first, last } = parseDirectorName(usName ?? "");
    const firstName = first || usName?.split(/\s+/)[0] || "";
    const lastName = last || usName?.split(/\s+/).slice(1).join(" ") || "";
    try {
      const r = await enrichWithLusha(firstName, lastName, domain, settings.lushaApiKey);
      const mobile = dedupePhone(r.ownerMobile, businessPhone);
      if (mobile) {
        steps.push("Lusha");
        return {
          ...partial,
          ...r,
          ownerName: usName || partial.ownerName,
          ownerMobile: mobile,
          mobileSource: "Lusha",
          source: waterfallSource(steps),
          enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
      }
      if (r.ownerEmail) partial = { ...partial, ownerEmail: r.ownerEmail };
    } catch (err) {
      stepErrors.push(`Lusha: ${String(err)}`);
    }
  }
  return finishWaterfall(partial, steps, stepErrors, businessName, settings, "US");
}
function finishWaterfall(partial, steps, stepErrors, businessName, settings, market) {
  const anyActive = settings.openmartApiKey && settings.openmartEnabled || settings.cognismApiKey && settings.cognismEnabled || settings.lushaApiKey && settings.lushaEnabled || chLiveModeActive(settings) && chApiKey(resolveChSettings(settings));
  if (!anyActive) {
    throw new Error("All waterfall providers are disabled or have no key. Enable at least one in Settings \u2192 Local SMB API Keys.");
  }
  if (partial.ownerName || (partial.openmartPeople?.length ?? 0) > 0 || partial.companiesHouseMatched) {
    const suffix = partial.ownerMobile ? "" : " (register/contact found \u2014 no personal mobile)";
    return {
      ...partial,
      source: steps.length ? `${waterfallSource(steps)}${suffix}` : `Partial match${suffix}`,
      enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  const hint = stepErrors.length ? `
${stepErrors.join("\n")}` : "";
  const flow = market === "UK" ? "UK: Companies House \u2192 Openmart \u2192 Cognism" : "US: Openmart \u2192 Lusha";
  throw new Error(`No owner data for "${businessName}". Expected flow: ${flow}.${hint}`);
}
function openmartBatchReady(body) {
  if (typeof body.batch_ready === "boolean") return body.batch_ready;
  if (typeof body.status?.batch_ready === "boolean") return body.status.batch_ready;
  const processing = body.processing ?? body.status?.processing;
  const completed = body.completed ?? body.status?.completed;
  const errored = body.errored ?? body.status?.errored;
  if (typeof processing === "number" && processing === 0 && (completed ?? 0) > 0) return true;
  if (typeof errored === "number" && errored > 0 && (completed ?? 0) === 0) return true;
  return false;
}
function openmartBatchFailed(body) {
  const errored = body.errored ?? body.status?.errored ?? 0;
  const completed = body.completed ?? body.status?.completed ?? 0;
  const processing = body.processing ?? body.status?.processing ?? 0;
  return errored > 0 && completed === 0 && processing === 0;
}
function normalizeOpenmartDomain(domain) {
  if (!domain) return void 0;
  const d = domain.replace(/^https?:\/\//i, "").replace(/^www\./i, "").split("/")[0]?.trim();
  if (!d || /^(facebook|instagram|tiktok|yelp|tripadvisor)\./i.test(d)) return void 0;
  return d;
}
function openmartCountryHint(country) {
  if (!country) return void 0;
  const c = country.toLowerCase();
  if (c.includes("united kingdom") || c === "uk" || c.includes("england")) return "GB";
  if (c.includes("united states") || c === "usa" || c === "us") return "US";
  return country.length <= 3 ? country.toUpperCase() : country;
}
async function parseOpenmartTaskIds(res) {
  const json = await res.json();
  if (Array.isArray(json)) return json;
  return json.task_ids ?? [];
}
async function enrichWithOpenmart(businessName, domain, apiKey, options = {}) {
  const BASE = "https://api.openmart.ai";
  const hdrs = { "X-API-Key": apiKey, "Content-Type": "application/json", "Accept": "application/json" };
  const cleanDomain = normalizeOpenmartDomain(domain);
  const payload = {
    company_name: options.companyName || businessName,
    title: options.title || "Owner",
    max_k: 5,
    info_access: ["EMAIL", "PHONE"]
  };
  if (cleanDomain) payload.domain = cleanDomain;
  if (options.city) payload.city = options.city;
  if (options.address) payload.address = options.address;
  if (options.ownerFirstName) payload.first_name = options.ownerFirstName;
  if (options.ownerLastName) payload.last_name = options.ownerLastName;
  const countryHint = openmartCountryHint(options.country);
  if (countryHint) payload.country = countryHint;
  const submitRes = await fetch(`${BASE}/api/v1/task/batch/find_people`, {
    method: "POST",
    headers: hdrs,
    body: JSON.stringify([payload]),
    signal: AbortSignal.timeout(9e4)
  });
  const submitJson = await submitRes.json();
  if (!submitRes.ok) {
    const detail = typeof submitJson.detail === "string" ? submitJson.detail : Array.isArray(submitJson.detail) ? submitJson.detail[0]?.msg : submitJson.message;
    throw new Error(`Openmart submit: ${submitRes.status}${detail ? ` \u2014 ${detail}` : ""}`);
  }
  const batch_id = submitJson.batch_id;
  if (!batch_id) throw new Error("Openmart submit: response missing batch_id");
  const deadline = Date.now() + 12e4;
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 5e3));
    const statusRes = await fetch(`${BASE}/api/v1/task/batch/${batch_id}/status`, { headers: hdrs });
    if (!statusRes.ok) continue;
    const statusBody = await statusRes.json();
    if (openmartBatchFailed(statusBody)) {
      throw new Error("Openmart: batch finished with errors (no match for this business)");
    }
    if (!openmartBatchReady(statusBody)) continue;
    const idsRes = await fetch(`${BASE}/api/v1/task/batch/${batch_id}/task_ids?status=COMPLETED`, { headers: hdrs });
    if (!idsRes.ok) throw new Error(`Openmart: failed to fetch task IDs (${idsRes.status})`);
    const task_ids = await parseOpenmartTaskIds(idsRes);
    if (!task_ids.length) throw new Error("Openmart: batch ready but no completed task IDs");
    const taskRes = await fetch(`${BASE}/api/v1/task/${task_ids[0]}`, { headers: hdrs });
    if (!taskRes.ok) throw new Error(`Openmart: failed to fetch task result (${taskRes.status})`);
    const task = await taskRes.json();
    if (task.status === "ERRORED") {
      throw new Error("Openmart: task errored (business not in registry or missing domain)");
    }
    const parsed = parseOpenmartTaskResult(task);
    return {
      ownerName: parsed.ownerName,
      ownerTitle: parsed.ownerTitle,
      ownerEmail: parsed.ownerEmail,
      ownerMobile: parsed.ownerMobile,
      ownerLinkedin: parsed.ownerLinkedin,
      openmartPeople: parsed.openmartPeople,
      enrichedAt: parsed.enrichedAt
    };
  }
  throw new Error("Openmart: timed out waiting for batch result (>120 s)");
}
async function enrichWithLusha(firstName, lastName, domain, apiKey) {
  const BASE = "https://api.lusha.com/v3";
  const hdrs = { "api_key": apiKey, "Content-Type": "application/json" };
  const searchBody = { companyDomain: domain };
  if (firstName) searchBody.firstName = firstName;
  if (lastName) searchBody.lastName = lastName;
  const searchRes = await fetch(`${BASE}/contacts/search`, {
    method: "POST",
    headers: hdrs,
    body: JSON.stringify(searchBody)
  });
  if (!searchRes.ok) throw new Error(`Lusha search: ${searchRes.status}`);
  const searchJson = await searchRes.json();
  const id = searchJson.contacts?.[0]?.id;
  if (!id) throw new Error(`Lusha: no match for ${firstName} ${lastName}`);
  const enrichRes = await fetch(`${BASE}/contacts/enrich`, {
    method: "POST",
    headers: hdrs,
    body: JSON.stringify({ ids: [id] })
  });
  if (!enrichRes.ok) throw new Error(`Lusha enrich: ${enrichRes.status}`);
  const enrichJson = await enrichRes.json();
  const c = enrichJson.contacts?.[0];
  const mobile = c?.phoneNumbers?.find((p) => p.type === "mobile" || p.type === "direct")?.number ?? c?.phoneNumbers?.[0]?.number;
  return {
    ownerMobile: mobile || void 0,
    ownerEmail: c?.emails?.[0]?.email || void 0,
    enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function enrichWithCognism(firstName, lastName, companyName, domain, apiKey) {
  const BASE = "https://app.cognism.com/api/search";
  const hdrs = { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" };
  const searchRes = await fetch(`${BASE}/contact/search`, {
    method: "POST",
    headers: hdrs,
    body: JSON.stringify({ firstName, lastName, companyName, companyDomain: domain, page: 1, pageSize: 5 })
  });
  if (!searchRes.ok) throw new Error(`Cognism search: ${searchRes.status}`);
  const searchJson = await searchRes.json();
  const id = searchJson.data?.contacts?.[0]?.id;
  if (!id) throw new Error(`Cognism: no match for ${firstName} ${lastName}`);
  const redeemRes = await fetch(`${BASE}/contact/redeem`, {
    method: "POST",
    headers: hdrs,
    body: JSON.stringify({ ids: [id] })
  });
  if (!redeemRes.ok) throw new Error(`Cognism redeem: ${redeemRes.status}`);
  const redeemJson = await redeemRes.json();
  const c = redeemJson.data?.contacts?.[0];
  return {
    ownerMobile: c?.mobilePhone || c?.directDial || void 0,
    ownerPhone: c?.directDial || void 0,
    ownerEmail: c?.businessEmail || void 0,
    enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
var CH_BASE = "https://api.company-information.service.gov.uk";
function chAuthHeaders(apiKey) {
  return { Authorization: `Basic ${btoa(apiKey + ":")}` };
}
function formatChAddress(addr) {
  return [
    addr.premises,
    addr.address_line_1,
    addr.address_line_2,
    addr.locality,
    addr.region,
    addr.postal_code,
    addr.country
  ].filter(Boolean).join(", ");
}
function assertCompaniesHouseConfig(settings) {
  const needsSearch = settings.companiesHouseUseOfficers || settings.companiesHouseUsePsc || settings.companiesHouseUseRegisteredAddress;
  if (needsSearch && !settings.companiesHouseUseSearch) {
    throw new Error("Companies House: enable Company search \u2014 required for other endpoints.");
  }
  if (!settings.companiesHouseUseSearch && !settings.companiesHouseUseOfficers && !settings.companiesHouseUsePsc && !settings.companiesHouseUseRegisteredAddress) {
    throw new Error("Companies House: enable at least one API endpoint in Settings.");
  }
}
function mapChToExplorium(ch) {
  const ownerName = ch.directorName || ch.pscName;
  const ownerType = ch.directorName ? "officers" : ch.pscName ? "psc" : ch.source;
  const label = ch.companyName ?? ch.companyNumber ?? "UK company";
  let source = `Companies House \u2014 ${label}`;
  if (ownerName) {
    source = ownerType === "psc" ? `Companies House (PSC) \u2014 ${label}` : `Companies House (director) \u2014 ${label}`;
  } else if (ch.companyNumber) {
    source = `Companies House \u2014 matched, no director/PSC person`;
  }
  return {
    ownerName,
    businessId: ch.companyNumber,
    companiesHouseCompanyName: ch.companyName,
    companiesHouseCompanyNumber: ch.companyNumber,
    companiesHouseCompanyStatus: ch.companyStatus,
    companiesHouseRegisteredAddress: ch.registeredOfficeAddress,
    companiesHouseDirectorName: ch.directorName,
    companiesHouseDirectorRole: ch.directorRole,
    companiesHousePscName: ch.pscName,
    companiesHouseOwnerType: ownerType,
    companiesHouseMatched: !!ch.companyNumber,
    companiesHouseNoOwner: !!ch.companyNumber && !ownerName,
    enrichedAt: (/* @__PURE__ */ new Date()).toISOString(),
    source
  };
}
async function lookupCompaniesHouse(businessName, settings) {
  assertCompaniesHouseConfig(settings);
  const apiKey = chApiKey(settings);
  if (!apiKey) return void 0;
  const auth = chAuthHeaders(apiKey);
  const result = {};
  if (settings.companiesHouseUseSearch) {
    const searchRes = await fetch(
      `${CH_BASE}/search/companies?q=${encodeURIComponent(businessName)}&items_per_page=5`,
      { headers: auth }
    );
    if (!searchRes.ok) return void 0;
    const searchJson = await searchRes.json();
    const company = searchJson.items?.[0];
    if (!company?.company_number) return void 0;
    result.companyNumber = company.company_number;
    result.companyName = company.title;
    result.companyStatus = company.company_status;
  }
  if (!result.companyNumber) return void 0;
  const { companyNumber } = result;
  if (settings.companiesHouseUseOfficers) {
    const officersRes = await fetch(
      `${CH_BASE}/company/${companyNumber}/officers?items_per_page=10`,
      { headers: auth }
    );
    if (officersRes.ok) {
      const officersJson = await officersRes.json();
      const director = officersJson.items?.find(
        (o) => !o.resigned_on && (o.officer_role === "director" || o.officer_role === "llp-designated-member")
      );
      if (director?.name) {
        result.directorName = director.name;
        result.directorRole = director.officer_role;
      }
    }
  }
  if (settings.companiesHouseUsePsc) {
    const pscRes = await fetch(
      `${CH_BASE}/company/${companyNumber}/persons-with-significant-control?items_per_page=10`,
      { headers: auth }
    );
    if (pscRes.ok) {
      const pscJson = await pscRes.json();
      const individual = pscJson.items?.find(
        (p) => !p.ceased_on && p.kind?.includes("individual")
      );
      if (individual) {
        result.pscName = individual.name || [individual.name_elements?.forename, individual.name_elements?.surname].filter(Boolean).join(" ") || void 0;
      }
    }
  }
  if (settings.companiesHouseUseRegisteredAddress) {
    const addrRes = await fetch(
      `${CH_BASE}/company/${companyNumber}/registered-office-address`,
      { headers: auth }
    );
    if (addrRes.ok) {
      const addrJson = await addrRes.json();
      const formatted = formatChAddress(addrJson);
      if (formatted) result.registeredOfficeAddress = formatted;
    }
  }
  result.ownerName = result.directorName || result.pscName;
  result.source = result.directorName ? "officers" : result.pscName ? "psc" : void 0;
  return result;
}
async function extractActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url) return null;
  const isLinkedIn = tab.url.includes("linkedin.com");
  try {
    return await chrome.tabs.sendMessage(tab.id, { type: "EXTRACT_PAGE" });
  } catch {
    try {
      await injectContentScript(tab.id);
      if (isLinkedIn) await new Promise((r) => setTimeout(r, 800));
      return await chrome.tabs.sendMessage(tab.id, { type: "EXTRACT_PAGE" });
    } catch {
    }
    return null;
  }
}
//# sourceMappingURL=background.js.map
